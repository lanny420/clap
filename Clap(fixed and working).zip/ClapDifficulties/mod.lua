
local text_original = LocalizationManager.text
local testAllStrings = false

function LocalizationManager:text(string_id, ...)
return string_id == "menu_difficulty_normal" and "eZ Clap"
or string_id == "menu_difficulty_hard" and "Clap"
or string_id == "menu_difficulty_very_hard" and "Very Clap"
or string_id == "menu_difficulty_overkill" and "OverClap"
or string_id == "menu_difficulty_easy_wish" and "MayClap"
or string_id == "menu_difficulty_apocalypse" and "ClapWish"
or string_id == "menu_difficulty_sm_wish" and "ClapSentence"

or string_id == "menu_risk_pd" and "EXP-Multiplier: x0"
or string_id == "menu_risk_swat" and "EXP-Multiplier: x2"
or string_id == "menu_risk_fbi" and "EXP-Multiplier: x5"
or string_id == "menu_risk_special" and "EXP-Multiplier: x10"
or string_id == "menu_risk_easy_wish" and "EXP-Multiplier: 11.5"
or string_id == "menu_risk_elite" and "EXP-Multiplier: x13"
or string_id == "menu_risk_sm_wish" and "EXP-Multiplier: x14"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end