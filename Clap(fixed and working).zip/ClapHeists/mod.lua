local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_jolly" and "AfterClap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end
 
local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_wwh" and "Alaskan Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_gallery" and "Clap Gallery"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_pbr" and "Beneath the Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_welcome_to_the_jungle" and "Clap Oil"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_pbr2" and "Birth of Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_mad" and "Boiling Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_cage" and "Clap Shop"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_rat" and "Clap Off"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_pal" and "CounterClap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_election_day" and "Election Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_red2" and "First World Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_four_stores" and "Four Claps"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_framing_frame" and "Framing Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_peta" and "Clap Simulator"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_kenaz_full" and "Golden Clap Casino"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_run" and "Clap Street"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_nail" and "Lab Claps"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_mallcrasher" and "MallClapper"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_shoutout_raid" and "ClapDown"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_dark" and "Clap Station"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_nightclub" and "Night Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_flat" and "Clap Room"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_alex" and "Claps"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_cane" and "Santa´s ClapShop"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_friend" and "ClapFace Mansion"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_kosugi" and "Shadow Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_dinner" and "SlaughterClap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_moon" and "Stealing ClapMas"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_arena" and "The Alesso Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_big" and "Big Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_crojob1" and "The Clap: Dockyard"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_crojob" and "The Clap: Forest"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_fish" and "The Yacht Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_pines" and "White ClapMas"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_rvd" and "Reservoir Claps"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_dah" and "Diamond Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_tag" and "Breaking Claps"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_brb" and "Brookly Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_nmh" and "No Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_sah" and "Shacklethorne Claption"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_mus" and "The Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_vit" and "The White Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end